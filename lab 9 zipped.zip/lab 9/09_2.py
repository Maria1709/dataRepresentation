import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password=""
)

mycursor = mydb.cursor()

#Create database
mycursor.execute("Create DATABASE datarepresentation")

#Create table
sql="CREATE TABLE student (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), age INT)"
mycursor.execute(sql)

#Insert Data
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="datarepresentation"
)
cursor = db.cursor()
sql="insert into student (name,age) values (%s,%s)"
values = ("Mary",21)
cursor.execute(sql, values)
db.commit()
print("1 record inserted, ID:", cursor.lastrowid)

#View data
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="datarepresentation"
)
cursor = db.cursor()
sql="select * from student where id = %s"
values = (1,)

cursor.execute(sql, values)
result = cursor.fetchall()
for x in result:
    print(x)

#Update data
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="datarepresentation"
)
cursor = db.cursor()
sql="update student set name = %s, age=%s where id = %s"
values = ('Joe',33,1)

cursor.execute(sql, values)
db.commit()
print("update done")

#Delete
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="datarepresentation"
)
cursor = db.cursor()
sql="delete from student where id = %s"
values = (1,)

cursor.execute(sql, values)

db.commit()
print("delete done")