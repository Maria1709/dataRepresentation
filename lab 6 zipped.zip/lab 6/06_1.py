import requests
import json
from xlwt import *

url = "http://127.0.0.1:5000/cars"

response = requests.get(url)
data = response.json()

print (data)                

#print cars to screen individually
for car in data['cars']:
    print (car)  


#write to a file
filename = 'cars.json'
if filename:
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)           


#Write to excel file
w = Workbook()
ws = w.add_sheet('cars')
row = 0;
ws.write(row,0,"reg")
ws.write(row,1,"make")
ws.write(row,2,"model")
ws.write(row,3,"price")
row += 1
for car in data['cars']:
    ws.write(row,0,car["reg"])
    ws.write(row,1,car["make"])
    ws.write(row,2,car["model"])
    ws.write(row,3,car["price"])
    row += 1
w.save('cars.xls')

#Create a car on the server
dataString = {'reg':'08 c 1234','make':'Ford','Model':'Galaxy','price':1234}
url = 'http://127.0.0.1:5000/cars'

response = requests.post(url, json=dataString)

print (response.status_code)

#Update a car on the server
dataString = {'make':'Ford','model':'Kuga'}
url = 'http://127.0.1.1:5000/cars/test'

response = requests.put(url, json=dataString)

print (response.status_code)
print (response.txt)

#Delete a car 
url = 'http://127.0.0.1:5000/cars/08%C%2011234'
response = requests.delete(url)
print (response.status_code)
print (response.text)

#Challange read from github
url = "https://api.github.com/users/andrewbeattycourseware/followers"
resonpse = requests.get(url)
data = resonpse.json()
filename = 'githubusers.json'
with open(filename, 'w') as f:
    json.dump(data, f, indent=4)

#Write to excel file
w = Workbook()
ws = w.add_sheet('githubusers')
row = 0;
ws.write(row,0,"login")
ws.write(row,1,"repos_url")

row += 1
for user in data['githubusers']:
    ws.write(row,0,user["login"])
    ws.write(row,1,user["repos_url"])

    row += 1
w.save('githubusers')