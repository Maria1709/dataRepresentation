import requests
import json

f = open("../../week02/carviewer.html", "r")
html = f.read()
print (html)

apiKey='46ceed910c24ff7cce8240e89ec7b71912f6f40f2ec55fd217ce150ad6d4f1c4'
url = 'https://apo.html2pdf.app/v1/generate'

data = {'html':html,'apiKey': apiKey}
response = requests.post(url, json=data)
print (response.status_code) 

newFile = open("lab06.02.01.htmlaspdf", "wb")
newFile.write(response.content)

#python script that will get the information from a private repository
apiKey='b55d312da577ba479f7dc4f8f3f5b1384bdf3b2-e'
url = '"https://api.github.com/users/datarepresentation/aPrivateOne'

response = requests.get(url, auth=('token', apiKey))

repoJSON = response.json()
print(response.json)
